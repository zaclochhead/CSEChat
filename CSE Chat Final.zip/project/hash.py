import hashlib

def hashText(text):
	hash_object = hashlib.sha256(text+'COMPSYS302-2017')
	return(hash_object.hexdigest())


