import sqlite3
import json
import urllib
import urllib2
import os.path
def messageDatabase(sent = None,sender=None,message=None, now = None):
	#create database called example
    conn = sqlite3.connect('database/messageDatabase.db')
    #create cursor object
    c = conn.cursor()        
    #create a table for the users info if it doesn't already exist 
    c.execute('''CREATE TABLE IF NOT EXISTS messages
          (sent text,sender text,message text,time text)''')
    if (sender and sent and message):
        details = []
        details.append(1)
        #if sent = 0 then message is received else if sent = 1 then message is sent 
        details[0]=sent
        details.append(1)
        details[1]=sender
        details.append(1)
        details[2]=message
        details.append(1)
        details[3]=now
        #insert user details into the database 
        c.executemany('INSERT INTO messages VALUES(?,?,?,?)',(details,)) 
        # Save (commit) the changes
        conn.commit()
    
    table_name = 'messages'
    chattingTo = 'sender'
    #return only the messages 
    c.execute("SELECT * FROM {tn} WHERE {coi1}='{sender}'".\
              format(coi1 = chattingTo,tn=table_name,sender = sender))
    all_rows = c.fetchall()
    conn.close()
    return all_rows
