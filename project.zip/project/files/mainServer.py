IyEvdXNyL2Jpbi9weXRob24KaW1wb3J0IGNoZXJyeXB5CmltcG9ydCB1cmxsaWIKaW1wb3J0IHVybGxpYjIKaW1wb3J0IGNvZGVjcwppbXBvcnQgc3lzCmltcG9ydCBqc29uCmltcG9ydCBvcy5wYXRoCmltcG9ydCB0aW1lCmltcG9ydCBiYXNlNjQKaW1wb3J0IHNxbGl0ZTMKZnJvbSBoYXNoIGltcG9ydCogCmZyb20gdXNlckRhdGFiYXNlIGltcG9ydCoKZnJvbSBtZXNzYWdlRGF0YWJhc2UgaW1wb3J0KgppbXBvcnQgc29ja2V0CmZyb20gdXNlckRldGFpbHMgaW1wb3J0Kgpmcm9tIHByb2ZpbGVEYXRhYmFzZSBpbXBvcnQqCgojIFRoZSBhZGRyZXNzIHdlIGxpc3RlbiBmb3IgY29ubmVjdGlvbnMgb24KbGlzdGVuX2lwID0gIjAuMC4wLjAiCnRyeTojIGlmIHBvcnQgYXJndW1lbnQgaXMgZGVmaW5lZCB0aGVuIHNldCBwb3J0IHRvIHRoaXMgCiAgICBsaXN0ZW5fcG9ydCA9IGludChzeXMuYXJndlsxXSkKZXhjZXB0IChJbmRleEVycm9yLCBUeXBlRXJyb3IpOgoJI290aGVyd2lzZSBtYWtlIGl0IDEwMDA0IGJ5IGRlZmF1bHQgCiAgICBsaXN0ZW5fcG9ydCA9IDEwMDA0CgpjbGFzcyBNYWluQXBwKG9iamVjdCk6CiAgICAjQ2hlcnJ5UHkgQ29uZmlndXJhdGlvbgogICAgX2NwX2NvbmZpZyA9IHsndG9vbHMuZW5jb2RlLm9uJzogVHJ1ZSwgCiAgICAgICAgICAgICAgICAgICd0b29scy5lbmNvZGUuZW5jb2RpbmcnOiAndXRmLTgnLAogICAgICAgICAgICAgICAgICAndG9vbHMuc2Vzc2lvbnMub24nIDogJ1RydWUnLAogICAgICAgICAgICAgICAgIH0gICAgICAgICAgICAgICAgIAogICAgCiAgICAjIElmIHRoZXkgdHJ5IHNvbWV3aGVyZSB3ZSBkb24ndCBrbm93LCBjYXRjaCBpdCBoZXJlIGFuZCBzZW5kIHRoZW0gdG8gdGhlIHJpZ2h0IHBsYWNlLgogICAgQGNoZXJyeXB5LmV4cG9zZQogICAgZGVmIGRlZmF1bHQoc2VsZiwgKmFyZ3MsICoqa3dhcmdzKToKICAgICAgICAiIiJUaGUgZGVmYXVsdCBwYWdlLCBnaXZlbiB3aGVuIHdlIGRvbid0IHJlY29nbmlzZSB3aGVyZSB0aGUgcmVxdWVzdCBpcyBmb3IuIiIiCiAgICAgICAgUGFnZSA9ICJJIGRvbid0IGtub3cgd2hlcmUgeW91J3JlIHRyeWluZyB0byBnbywgc28gaGF2ZSBhIDQwNCBFcnJvci4iCiAgICAgICAgY2hlcnJ5cHkucmVzcG9uc2Uuc3RhdHVzID0gNDA0CiAgICAgICAgcmV0dXJuIFBhZ2UKICAgICAgICAKCiAgICAjSU5ERVgKICAgIEBjaGVycnlweS5leHBvc2UKICAgIGRlZiBpbmRleChzZWxmKTojaW5kZXggaXMgdGhlIGRlZmF1bHQgcGFnZSAJCQogICAgICAgIHRyeToKICAgICAgICAjb3BlbiB0aGUgbWVzc2FnZSB0aGF0IGhhcyBiZWVuIHNlbnQgdG8gdGhpcyBwb3J0CiAgICAgICAgICAgIFBhZ2UgPSAnLicKICAgICAgICAgICAgdmFyID0gJycKICAgICAgICAgICAgI2NyZWF0ZSBkYXRhYmFzZSBjYWxsZWQgZXhhbXBsZQogICAgICAgICAgICBjb25uID0gc3FsaXRlMy5jb25uZWN0KCdkYXRhYmFzZS9tZXNzYWdlRGF0YWJhc2UuZGInKQogICAgICAgICAgICAjY3JlYXRlIGN1cnNvciBvYmplY3QKICAgICAgICAgICAgYyA9IGNvbm4uY3Vyc29yKCkKICAgICAgICAgICAgYy5leGVjdXRlKCcnJ0NSRUFURSBUQUJMRSBJRiBOT1QgRVhJU1RTIG1lc3NhZ2VzCiAgICAgICAgICAgICAgICAgKHNlbnQgdGV4dCxzZW5kZXIgdGV4dCxtZXNzYWdlIHRleHQsdGltZSB0ZXh0KScnJykKICAgICAgICAgICAgI2NoZWNrIHRoYXQgdGhlIGRhdGFiYXNlIGlzIG5vdCBlbXB0eSAKICAgICAgICAgICAgYy5leGVjdXRlKCIiIlNFTEVDVCBjb3VudCgqKSBhcyB0b3QgRlJPTSBtZXNzYWdlcyIiIikKICAgICAgICAgICAgZGF0YSA9IGMuZmV0Y2hvbmUoKQogICAgICAgICAgICAjZGlzcGxheSB0aGUgbWVzc2FnZXMgb250byB0aGUgcGFnZSAnJycKICAgICAgICAgICAgaWYgZGF0YT4wOgogICAgICAgICAgICAgICAgZm9yIG1lcyBpbiBtZXNzYWdlRGF0YWJhc2UoTm9uZSxjaGVycnlweS5zZXNzaW9uWydyZWNlaXZlciddLE5vbmUsTm9uZSk6CiAgICAgICAgICAgICAgICAgICAgdGV4dCA9ICcnLmpvaW4obWVzWzJdKQogICAgICAgICAgICAgICAgICAgIHRpbWUgPSAnJy5qb2luKG1lc1szXSkKICAgICAgICAgICAgICAgICAgICBpZiBsZW4obWVzWzJdKTw1NToKICAgICAgICAgICAgICAgICAgICAgICAgY29sTGVuZ3RoID0gc3RyKGxlbihtZXNbMl0pKQogICAgICAgICAgICAgICAgICAgICAgICByb3dMZW5ndGggPSAnMScKICAgICAgICAgICAgICAgICAgICBlbHNlOgogICAgICAgICAgICAgICAgICAgICAgICByb3dMZW5ndGggPSBzdHIoKGxlbihtZXNbMl0pLzU1KSsxKQogICAgICAgICAgICAgICAgICAgICAgICBjb2xMZW5ndGggPSAnNTUnCiAgICAgICAgICAgICAgICAgICAgaWYgbWVzWzBdID09ICcwJzoKICAgICAgICAgICAgICAgICAgICAgICAgdmFyKz1vcGVuKCJodG1sL21lc3NhZ2VGb3JtYXR0aW5nUmVjZWl2ZWQuaHRtIikucmVhZCgpLmZvcm1hdCh0aW1lUmVjZWl2ZWQ9dGltZSxtZXNzYWdlPXRleHQsY29sTGVuZ3RoUj1jb2xMZW5ndGgscm93TGVuZ3RoUj1yb3dMZW5ndGgpKyI8L2JyPiIKICAgICAgICAgICAgICAgICAgICBlbGlmIG1lc1swXSA9PSAnMSc6CiAgICAgICAgICAgICAgICAgICAgICAgIHZhcis9b3BlbigiaHRtbC9tZXNzYWdlRm9ybWF0dGluZ1NlbnQuaHRtIikucmVhZCgpLmZvcm1hdCh0aW1lUmVjZWl2ZWQ9dGltZSxtZXNzYWdlPXRleHQsY29sTGVuZ3RoUj1jb2xMZW5ndGgscm93TGVuZ3RoUj1yb3dMZW5ndGgpKyI8L2JyPiIKICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgIFBhZ2UrPW9wZW4oImh0bWwvbWVzc2FnZURpc3BsYXkuaHRtIikucmVhZCgpLmZvcm1hdChtZXNzYWdlPXZhcixzZW50PScnKQogICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgZnVsbE5hbWU9J1Vua25vd24nCiAgICAgICAgICAgIHVzZXJQb3NpdGlvbj0nVW5rbm93bicKICAgICAgICAgICAgdXNlckRlc2NyaXB0aW9uPSdOb25lJwogICAgICAgICAgICBpbWFnZT0naHR0cHM6Ly93aWtpLnNoaWJib2xldGgubmV0L2NvbmZsdWVuY2UvaW1hZ2VzL2ljb25zL3Byb2ZpbGVwaWNzL2RlZmF1bHQucG5nJwogICAgICAgICAgICBsb2NhdGU9J1Vua25vd24nCiAgICAgICAgICAgIAogICAgICAgICAgICAKCQkJCiAgICAgICAgICAgIGlmIGNoZXJyeXB5LnNlc3Npb25bJ3JlY2VpdmVyJ10hPSd1c2VyJzogIAogICAgICAgICAgICAgICB0cnk6ICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgaiA9IHNlbGYucmVxdWVzdFByb2ZpbGUoKQogICAgICAgICAgICAgICAgICAgIGRldGFpbHNMaXN0ID0ganNvbi5sb2FkcyhqKQogICAgICAgICAgICAgICAgICAgIGZ1bGxOYW1lID0gZGV0YWlsc0xpc3RbJ2Z1bGxuYW1lJ10KICAgICAgICAgICAgICAgICAgICB1c2VyUG9zaXRpb24gPSBkZXRhaWxzTGlzdFsncG9zaXRpb24nXQogICAgICAgICAgICAgICAgICAgIHVzZXJEZXNjcmlwdGlvbiA9IGRldGFpbHNMaXN0WydkZXNjcmlwdGlvbiddCiAgICAgICAgICAgICAgICAgICAgaW1hZ2UgPSBkZXRhaWxzTGlzdFsncGljdHVyZSddCiAgICAgICAgICAgICAgICAgICAgbG9jYXRlID0gZGV0YWlsc0xpc3RbJ2xvY2F0aW9uJ10KICAgICAgICAgICAgICAgZXhjZXB0IFR5cGVFcnJvcjoKICAgICAgICAgICAgICAgICAgICBmdWxsTmFtZT0nVW5rbm93bicKICAgICAgICAgICAgICAgICAgICB1c2VyUG9zaXRpb249J1Vua25vd24nCiAgICAgICAgICAgICAgICAgICAgdXNlckRlc2NyaXB0aW9uPSdOb25lJwogICAgICAgICAgICAgICAgICAgIGltYWdlPSdodHRwczovL3dpa2kuc2hpYmJvbGV0aC5uZXQvY29uZmx1ZW5jZS9pbWFnZXMvaWNvbnMvcHJvZmlsZXBpY3MvZGVmYXVsdC5wbmcnCiAgICAgICAgICAgICAgICAgICAgbG9jYXRlPSdVbmtub3duJwoJCQkJCQoKICAgICAgICAgICAgI2Rpc3BsYXkgaHRtbCBmb3IgcGFnZSAgICAgICAgIAogICAgICAgICAgICBQYWdlICs9IG9wZW4oImh0bWwvbWVzc2FnaW5nUGFnZS5odG0iLCJyIikucmVhZCgpLmZvcm1hdCh1c2VyID1jaGVycnlweS5zZXNzaW9uWydyZWNlaXZlciddLHJlY2VpdmVyPWZ1bGxOYW1lLHBvc2l0aW9uPXVzZXJQb3NpdGlvbixkZXNjcmlwdGlvbj11c2VyRGVzY3JpcHRpb24saW1nPWltYWdlLGxvY2F0aW9uPWxvY2F0ZSkKICAgICAgICAgICAgCiAgICAgICAgICAgIHVzZXJzPSB1c2VyRGF0YWJhc2UoY2hlcnJ5cHkuc2Vzc2lvblsndXNlcm5hbWUnXSxjaGVycnlweS5zZXNzaW9uWydwYXNzd29yZCddKQogICAgICAgICAgICB0ZW1wPScnCiAgICAgICAgICAgICNkaXNwbGF5IGFsbCBvZiB0aGUgdXNlcnMgY3VycmVudGx5IG9ubGluZQogICAgICAgICAgICBmb3IgdXNlciBpbiB1c2VyczoKICAgICAgICAgICAgICAgIHRlbXArPW9wZW4oImh0bWwvdXNlckxpbmtzLmh0bSIpLnJlYWQoKS5mb3JtYXQodXBpPScnLmpvaW4odXNlcikpCiAgICAgICAgICAgICNQYWdlKz1zdHIodGVtcCkKICAgICAgICAgICAgUGFnZSs9b3BlbigiaHRtbC91c2VyRGlzcGxheS5odG0iKS5yZWFkKCkuZm9ybWF0KGxpc3Q9c3RyKHRlbXApKSAgCiAgICAgICAgICAgICAKICAgICAgICBleGNlcHQgS2V5RXJyb3I6CiAgICAgCSNpZiB0aGVyZXMgbm8gdXNlcm5hbWUgd2UgY2FudCBsb2dpbiBzbyBzaG93IGxvZ2luIG9wdGlvbiB1bnRpbCB0aGVyZSBpcyBhIHVzZXJuYW1lIGlucHV0CiAgICAgICAgICAgIFBhZ2UgPSAiLiIgIAogICAgICAgICAgICBmPW9wZW4oImh0bWwvbG9naW5QYWdlLmh0bSIsICJyIikKICAgICAgICAgICAgUGFnZSArPSBmLnJlYWQoKQogICAgICAgICAgICBmLmNsb3NlKCkKICAgICAgICByZXR1cm4gUGFnZSNyZXR1cm4gYWxsIHRoZSBodG1sIAogICAgICAgIAogICAgICAgIAogICAgQGNoZXJyeXB5LmV4cG9zZQogICAgZGVmIGNsZWFyTWVzc2FnZXMoc2VsZik6CiAgICAgICAgI2NyZWF0ZSBkYXRhYmFzZSBjYWxsZWQgZXhhbXBsZQogICAgICAgIGNvbm4gPSBzcWxpdGUzLmNvbm5lY3QoJ2RhdGFiYXNlL21lc3NhZ2VEYXRhYmFzZS5kYicpCiAgICAgICAgI2NyZWF0ZSBjdXJzb3Igb2JqZWN0CiAgICAgICAgYyA9IGNvbm4uY3Vyc29yKCkKICAgICAgICBjLmV4ZWN1dGUoJ2RlbGV0ZSBmcm9tIG1lc3NhZ2VzJykKICAgICAgICBjb25uLmNvbW1pdCgpCiAgICAgICAgcmFpc2UgY2hlcnJ5cHkuSFRUUFJlZGlyZWN0KCcvJykKICAgICAgICAKCiAgICAjU0lHTiBJTiAKICAgIEBjaGVycnlweS5leHBvc2UKICAgIGRlZiBzaWduaW4oc2VsZiwgdXNlcm5hbWU9Tm9uZSwgcGFzc3dvcmQ9Tm9uZSk6CiAgICAgICAgIiIiQ2hlY2sgdGhlaXIgbmFtZSBhbmQgcGFzc3dvcmQgYW5kIHNlbmQgdGhlbSBlaXRoZXIgdG8gdGhlIG1haW4gcGFnZSwgb3IgYmFjayB0byB0aGUgbWFpbiBsb2dpbiBzY3JlZW4uIiIiCiAgICAgICAgaGFzaGVkUGFzc3dvcmQ9aGFzaFRleHQocGFzc3dvcmQpCiAgICAgICAgZXJyb3IgPSBzZWxmLmF1dGhvcmlzZVVzZXJMb2dpbih1c2VybmFtZSxoYXNoZWRQYXNzd29yZCkjY2FsbGluZyB0aGUgYXV0aGVyaXplIHVzZXJuYW1lIGFwaSAKICAgICAgICBpZiAoZXJyb3IgPT0gMCk6CiAgICAgICAgICAgIGNoZXJyeXB5LnNlc3Npb25bJ3VzZXJuYW1lJ10gPSB1c2VybmFtZQogICAgICAgICAgICBjaGVycnlweS5zZXNzaW9uWydwYXNzd29yZCddID0gaGFzaGVkUGFzc3dvcmQKICAgICAgICAgICAgY2hlcnJ5cHkuc2Vzc2lvblsncmVjZWl2ZXInXSA9ICd1c2VyJwogICAgICAgICAgICByYWlzZSBjaGVycnlweS5IVFRQUmVkaXJlY3QoJy8nKQogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIGNoZXJyeXB5LkhUVFBSZWRpcmVjdCgnLycpCiAgICAgICAgICAgIAoKICAgICNTSUdOIE9VVAogICAgQGNoZXJyeXB5LmV4cG9zZQogICAgZGVmIHNpZ25vdXQoc2VsZik6CiAgICAgICAgIiIiTG9ncyB0aGUgY3VycmVudCB1c2VyIG91dCwgZXhwaXJlcyB0aGVpciBzZXNzaW9uIiIiCiAgICAgICAgdXNlcm5hbWUgPSBjaGVycnlweS5zZXNzaW9uLmdldCgndXNlcm5hbWUnKQogICAgICAgIHBhc3N3b3JkID0gY2hlcnJ5cHkuc2Vzc2lvblsncGFzc3dvcmQnXQogICAgICAgICNpZiBubyBvbmVzIHNpZ24gaW4geWV0IHRoZW4gZG8gbm90aGluZwogICAgICAgIGRlc3QgPSAiaHR0cDovL2NzMzAyLnB5dGhvbmFueXdoZXJlLmNvbS9sb2dvZmYiI2NhbGxpbmcgdGhlIGxvZ2luIGFwaSB0byByZWNvcmQgdGhlIGhhcmRjb2RlZCB2YWx1ZXMgCiAgICAgICAgcG9zdGRhdGEgPSB7InVzZXJuYW1lIjogdXNlcm5hbWUsICJwYXNzd29yZCI6IHBhc3N3b3JkLCJlbmMiOjB9CiAgICAgICAgZnB0ciA9IHVybGxpYjIudXJsb3BlbihkZXN0LHVybGxpYi51cmxlbmNvZGUocG9zdGRhdGEpKQogICAgICAgIGRhdGEgPSBmcHRyLnJlYWQoKQogICAgICAgIGlmIChkYXRhID09ICIwLCBMb2dnZWQgb2ZmIHN1Y2Nlc3NmdWxseSIpOgogICAgICAgICAgICBjaGVycnlweS5saWIuc2Vzc2lvbnMuZXhwaXJlKCkKICAgICAgICAgICAgcmFpc2UgY2hlcnJ5cHkuSFRUUFJlZGlyZWN0KCcvJykjcmVkaXJlY3QgdG8gdGhlIGRlc2lyZWQgcGFnZQogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIGNoZXJyeXB5LkhUVFBSZWRpcmVjdCgnLycpI3JlZGlyZWN0IHRvIHRoZSBkZXNpcmVkIHBhZ2UgCiAgICAgICAgCiAKICAgICNDU1MgVFlQRSAgIAogICAgQGNoZXJyeXB5LmV4cG9zZQogICAgZGVmIGNzcyhzZWxmLGZuYW1lKToKICAgICAgICBmPW9wZW4oJ2Nzcy8nK2ZuYW1lLCJyIikKICAgICAgICBkYXRhPWYucmVhZCgpCiAgICAgICAgZi5jbG9zZSgpCiAgICAgICAgcmV0dXJuIGRhdGEKICAgICAgICAKCiAgICAjSU1HIFRZUEUgCiAgICBAY2hlcnJ5cHkuZXhwb3NlCiAgICBkZWYgaW1nKHNlbGYsIGZuYW1lKToKICAgICAgICBmPW9wZW4oJ2ltYWdlcy8nK2ZuYW1lLCAicmIiKQogICAgICAgIGRhdGEgPSBmLnJlYWQoKQogICAgICAgIGYuY2xvc2UoKQogICAgICAgIHJldHVybiBkYXRhCiAgICAgICAgCiAgICAgICAgCiAgICAjQVVUSE9SSVNFIFVTRVIgTE9HSU4gCiAgICAjbm90IHB1YmxpY2FsbHkgZXhwb3NlZAogICAgZGVmIGF1dGhvcmlzZVVzZXJMb2dpbihzZWxmLCB1c2VybmFtZSwgcGFzc3dvcmQpOgogICAgICAgIGRlc3QgPSAiaHR0cDovL2NzMzAyLnB5dGhvbmFueXdoZXJlLmNvbS9yZXBvcnQiI2NhbGxpbmcgdGhlIGxvZ2luIGFwaSB0byByZWNvcmQgdGhlIGhhcmRjb2RlZCB2YWx1ZXMgCiAgICAgICAgbG9jYXRpb24gPSAyCiAgICAgICAgaWYgbG9jYXRpb24gPT0xOgogICAgICAgICAgICBpcCA9IChzb2NrZXQuZ2V0aG9zdGJ5bmFtZShzb2NrZXQuZ2V0aG9zdG5hbWUoKSkpCiAgICAgICAgZWxpZiBsb2NhdGlvbiA9PTI6CgkJCWlwID0gdXJsbGliMi51cmxvcGVuKCdodHRwOi8vaXAuNDIucGwvcmF3JykucmVhZCgpCiAgICAgICAgcG9ydCA9IHN0cihsaXN0ZW5fcG9ydCkKICAgICAgICBwb3N0ZGF0YSA9IHsidXNlcm5hbWUiOiB1c2VybmFtZSwgInBhc3N3b3JkIjogcGFzc3dvcmQsImxvY2F0aW9uIjoyLCJpcCI6aXAsInBvcnQiOnBvcnQsImVuYyI6MH0KICAgICAgICBmcHRyID0gdXJsbGliMi51cmxvcGVuKGRlc3QsdXJsbGliLnVybGVuY29kZShwb3N0ZGF0YSkpCiAgICAgICAgZGF0YSA9IGZwdHIucmVhZCgpCiAgICAgICAgaWYgKGRhdGEgPT0gIjAsIFVzZXIgYW5kIElQIGxvZ2dlZCIpOgogICAgICAgICAgICByZXR1cm4gMAogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJldHVybiAxCiAgICAgICAgICAgIAogICAgICAgICAgICAKICAgICNSRUNFSVZFIE1FU1NBR0UKICAgIEBjaGVycnlweS5leHBvc2UKICAgIEBjaGVycnlweS50b29scy5qc29uX2luKCkgCiAgICBkZWYgcmVjZWl2ZU1lc3NhZ2Uoc2VsZik6CiAgICAgICAganNvbkRpY3QgPSBjaGVycnlweS5yZXF1ZXN0Lmpzb24KICAgICAgICBlcG9jaCA9IGpzb25EaWN0WydzdGFtcCddCiAgICAgICAgbm93ID0gdGltZS5zdHJmdGltZSgiJWQtJW0tJVkgJUk6JU0gJXAiLHRpbWUubG9jYWx0aW1lKGVwb2NoKSkKICAgICAgICBtZXNzYWdlRGF0YWJhc2UoJzAnLGpzb25EaWN0WydzZW5kZXInXSxqc29uRGljdFsnbWVzc2FnZSddLG5vdykgCiAgICAgICAgcmV0dXJuICcwJwogICAgICAgIAogICAgICAgIAogICAgI1NFTkQgTUVTU0FHRQogICAgQGNoZXJyeXB5LmV4cG9zZSAgCiAgICBkZWYgc2VuZE1lc3NhZ2Uoc2VsZixtZXNzYWdlLG1hcmtEb3duID0gMCxlbmNyeXB0aW9uID0gMCwgaGFzaGluZyA9IDAsIGRlY3J5cHRpb25LZXk9IDAsaGFzaDEgPSAwKToKICAgICAgICB0cnk6CgkJCSNhbGwgb2YgdGhlIHJlY2VpdmluZyB1c2VycyBnZXRMaXN0IGluZm8gaW4gYSBsaXN0CiAgICAgICAgICAgIHJlY2VpdmVyRGV0YWlscyA9IHVzZXJEZXRhaWxzKGNoZXJyeXB5LnNlc3Npb25bJ3JlY2VpdmVyJ10pCiAgICAgICAgICAgICNyZWNlaXZpbmcgdXNlcnMgdXBpCiAgICAgICAgICAgIGRlc3RpbmF0aW9uID0gcmVjZWl2ZXJEZXRhaWxzWzBdCiAgICAgICAgICAgICNob3N0cyB1cGkKICAgICAgICAgICAgc2VuZGVyID0gY2hlcnJ5cHkuc2Vzc2lvblsndXNlcm5hbWUnXQogICAgICAgICAgICAjcmVjZWl2aW5nIHVzZXJzIGlwCiAgICAgICAgICAgIHJlY2VpdmVySVAgPSByZWNlaXZlckRldGFpbHNbMV0KICAgICAgICAgICAgI3JlY2VpdmluZyB1c2VycyBwb3J0IAogICAgICAgICAgICByZWNlaXZlclBvcnQgPSByZWNlaXZlckRldGFpbHNbNV0KICAgICAgICAgICAgI3Rlc3QgdGhlIHVzZXJzIHBpbmcgQVBJIGZpcnN0IAogICAgICAgICAgICAjcGluZyA9ICJodHRwOi8vIityZWNlaXZlcklQKyI6IisgcmVjZWl2ZXJQb3J0KyIvcGluZyIKICAgICAgICAgICAgI3N0YW1wKGVwb2NoIHRpbWUgZmxvYXQpCiAgICAgICAgICAgIGVwb2NoID0gZmxvYXQodGltZS50aW1lKCkpCiAgICAgICAgICAgICNkYXRlIHllYXIgYW5kIHRpbWUgb2Ygc2VudCBtZXNzYWdlIAogICAgICAgICAgICBub3cgPSB0aW1lLnN0cmZ0aW1lKCIlZC0lbS0lWSAlSTolTSAlcCIsdGltZS5sb2NhbHRpbWUoZmxvYXQodGltZS5ta3RpbWUodGltZS5sb2NhbHRpbWUoKSkpKSkgIAogICAgICAgICAgICAjbGlzdCBvZiBkYXRhIHRvIHNlbmQgCiAgICAgICAgICAgIHBvc3RkYXRhID0geyJzZW5kZXIiOnNlbmRlciwiZGVzdGluYXRpb24iOmRlc3RpbmF0aW9uLCJtZXNzYWdlIjogbWVzc2FnZSwic3RhbXAiOmVwb2NoLCJlbmNyeXB0aW9uIjplbmNyeXB0aW9uLCJoYXNoaW5nIjpoYXNoaW5nLCJoYXNoIjpoYXNoMSwiZGVjcnlwdGlvbktleSI6ZGVjcnlwdGlvbktleX0KICAgICAgICAgICAgI2pzb24gZW5jb2RlIGRhdGEgCiAgICAgICAgICAgIHBvc3Rqc29uID0ganNvbi5kdW1wcyhwb3N0ZGF0YSkKICAgICAgICAgICAgZGVzdCA9ICJodHRwOi8vIitzdHIocmVjZWl2ZXJJUCkrIjoiK3N0cihyZWNlaXZlclBvcnQpKyIvcmVjZWl2ZU1lc3NhZ2UiCiAgICAgICAgICAgICNkZXN0ID0gImh0dHA6Ly8xMjcuMC4wLjE6MjM0NS9yZWNlaXZlTWVzc2FnZSIKICAgICAgICAgICAgcmVxID0gdXJsbGliMi5SZXF1ZXN0KGRlc3QscG9zdGpzb24sIHsnQ29udGVudC1UeXBlJzonYXBwbGljYXRpb24vanNvbid9KSAgIAogICAgICAgICAgICBtZXNzYWdlRGF0YWJhc2UoJzEnLGRlc3RpbmF0aW9uLG1lc3NhZ2Usbm93KQogICAgICAgICAgICByZXNwb25zZSA9IHVybGxpYjIudXJsb3BlbihyZXEpIAogICAgICAgICAgICByYWlzZSBjaGVycnlweS5IVFRQUmVkaXJlY3QoIi8iKQogICAgICAgIGV4Y2VwdCB1cmxsaWIyLlVSTEVycm9yOgoJCQlyZXR1cm4gIlVzZXIgY2Fubm90IGN1cnJlbnRseSByZWNlaXZlIG1lc3NhZ2VzICIKCQkJCgkJCQoJICAgICNSRUNFSVZFIE1FU1NBR0UKICAgIEBjaGVycnlweS5leHBvc2UKICAgIEBjaGVycnlweS50b29scy5qc29uX2luKCkgCiAgICBkZWYgcmVjZWl2ZUZpbGUoc2VsZik6CiAgICAgICAganNvbkRpY3QgPSBjaGVycnlweS5yZXF1ZXN0Lmpzb24KICAgICAgICBlcG9jaCA9IGpzb25EaWN0WydzdGFtcCddCiAgICAgICAgbm93ID0gdGltZS5zdHJmdGltZSgiJWQtJW0tJVkgJUk6JU0gJXAiLHRpbWUubG9jYWx0aW1lKGVwb2NoKSkKICAgICAgICBtZmlsZSA9IG9wZW4oImZpbGVzLyIranNvbkRpY3RbJ2ZpbGVuYW1lJ10sICJhIikKICAgICAgICBtZmlsZS53cml0ZShqc29uRGljdFsnZmlsZSddKQogICAgICAgIG1maWxlLmNsb3NlKCkKICAgICAgICBtZXNzYWdlRGF0YWJhc2UoJzQnLGpzb25EaWN0WydzZW5kZXInXSxqc29uRGljdFsnZmlsZW5hbWUnXSxub3cpIAogICAgICAgIHJldHVybiAnMCcKICAgICAgICAKICAgICAgICAJCiAgICBAY2hlcnJ5cHkuZXhwb3NlCQkKICAgIGRlZiBzZW5kRmlsZShzZWxmLGZpbGVuYW1lLG1pbWVUeXBlKToKCSAgICAjYWxsIG9mIHRoZSByZWNlaXZpbmcgdXNlcnMgZ2V0TGlzdCBpbmZvIGluIGEgbGlzdAogICAgICAgIHJlY2VpdmVyRGV0YWlscyA9IHVzZXJEZXRhaWxzKGNoZXJyeXB5LnNlc3Npb25bJ3JlY2VpdmVyJ10pCiAgICAgICAgI2hvc3RzIHVwaQogICAgICAgIHNlbmRlciA9IGNoZXJyeXB5LnNlc3Npb25bJ3VzZXJuYW1lJ10KICAgICAgICAjcmVjZWl2aW5nIHVzZXJzIGlwCiAgICAgICAgcmVjZWl2ZXJJUCA9IHJlY2VpdmVyRGV0YWlsc1sxXQogICAgICAgICNyZWNlaXZpbmcgdXNlcnMgcG9ydCAKICAgICAgICByZWNlaXZlclBvcnQgPSByZWNlaXZlckRldGFpbHNbNV0KICAgICAgICBlbmNyeXB0aW9uID0gJzAnCiAgICAgICAgaGFzaDE9JzAnCiAgICAgICAgaGFzaGluZz0nMCcKICAgICAgICBkZWNyeXB0aW9uS2V5PScwJwogICAgICAgIHNlbmRlciA9IGNoZXJyeXB5LnNlc3Npb25bJ3VzZXJuYW1lJ10KICAgICAgICBkZXN0aW5hdGlvbiA9IGNoZXJyeXB5LnNlc3Npb25bJ3JlY2VpdmVyJ10KCQkjc3RhbXAoZXBvY2ggdGltZSBmbG9hdCkKICAgICAgICBlcG9jaCA9IGZsb2F0KHRpbWUudGltZSgpKQogICAgICAgIG5vdyA9IHRpbWUuc3RyZnRpbWUoIiVkLSVtLSVZICVJOiVNICVwIix0aW1lLmxvY2FsdGltZShlcG9jaCkpCiAgICAgICAgd2l0aCBvcGVuKCJtYWluU2VydmVyLnB5IiwgInJiIikgYXMgaW1hZ2VfZmlsZToKICAgICAgICAgICAgZmlsZUI2NCA9IGJhc2U2NC5iNjRlbmNvZGUoaW1hZ2VfZmlsZS5yZWFkKCkpCiAgICAgICAgY29udGVudFR5cGUgPSAndGV4dCcKICAgICAgICBwb3N0ZGF0YSA9IHsic2VuZGVyIjpzZW5kZXIsImRlc3RpbmF0aW9uIjpkZXN0aW5hdGlvbiwiZmlsZSI6IGZpbGVCNjQsImZpbGVuYW1lIjpmaWxlbmFtZSwiY29udGVudF90eXBlIjptaW1lVHlwZSwic3RhbXAiOmVwb2NoLCJlbmNyeXB0aW9uIjplbmNyeXB0aW9uLCJoYXNoaW5nIjpoYXNoaW5nLCJoYXNoIjpoYXNoMSwiZGVjcnlwdGlvbktleSI6ZGVjcnlwdGlvbktleX0KICAgICAgICAjanNvbiBlbmNvZGUgZGF0YSAKICAgICAgICBwb3N0anNvbiA9IGpzb24uZHVtcHMocG9zdGRhdGEpCiAgICAgICAgI2Rlc3QgPSAiaHR0cDovLyIrc3RyKHJlY2VpdmVySVApKyI6IitzdHIocmVjZWl2ZXJQb3J0KSsiL3JlY2VpdmVGaWxlIgogICAgICAgIGRlc3QgPSAiaHR0cDovLzEyNy4wLjAuMToyMzQ1L3JlY2VpdmVGaWxlIgogICAgICAgIHJlcSA9IHVybGxpYjIuUmVxdWVzdChkZXN0LHBvc3Rqc29uLCB7J0NvbnRlbnQtVHlwZSc6J2FwcGxpY2F0aW9uL2pzb24nfSkgICAKICAgICAgICBtZXNzYWdlRGF0YWJhc2UoJzMnLGRlc3RpbmF0aW9uLGZpbGVuYW1lLG5vdykKICAgICAgICByZXNwb25zZSA9IHVybGxpYjIudXJsb3BlbihyZXEpIAogICAgICAgIHJhaXNlIGNoZXJyeXB5LkhUVFBSZWRpcmVjdCgiLyIpCiAgICAgICAgCiAgICAgICAgCiAgICAgICAgCgkjc2V0IHJlY2VpdmVyCQogICAgQGNoZXJyeXB5LmV4cG9zZQogICAgZGVmIHNldFJlY2VpdmVyKHNlbGYscmVjZWl2ZXIpOgogICAgICAgIGNoZXJyeXB5LnNlc3Npb25bJ3JlY2VpdmVyJ10gPSByZWNlaXZlcgogICAgICAgIHJhaXNlIGNoZXJyeXB5LkhUVFBSZWRpcmVjdCgiLyIpCgogICAgICAgIAogICAjR2V0IFByb2ZpbGUKICAgIEBjaGVycnlweS5leHBvc2UgIAogICAgQGNoZXJyeXB5LnRvb2xzLmpzb25faW4oKSAKICAgIGRlZiBnZXRQcm9maWxlKHNlbGYpOgogICAgICAgIGpzb25EaWN0ID0gY2hlcnJ5cHkucmVxdWVzdC5qc29uCgkJI2Nvbm5lY3QgdG8gcHJvZmlsZWRhdGFiYXNlCiAgICAgICAgY29ubiA9IHNxbGl0ZTMuY29ubmVjdCgnZGF0YWJhc2UvcHJvZmlsZURhdGFiYXNlLmRiJykKICAgICAgICAjY3JlYXRlIGN1cnNvciBvYmplY3QKICAgICAgICBjID0gY29ubi5jdXJzb3IoKQogICAgICAgIGMuZXhlY3V0ZSgnJydDUkVBVEUgVEFCTEUgSUYgTk9UIEVYSVNUUyB1c2Vyc1Byb2ZpbGUKICAgICAgICAgICAgICAoc2VudCB0ZXh0LHNlbmRlciB0ZXh0LG1lc3NhZ2UgdGV4dCx0aW1lIHRleHQpJycnKQogICAgICAgICNjaGVjayB0aGF0IHRoZSB0YWJsZSBpcyBub3QgZW1wdHkgCiAgICAgICAgYy5leGVjdXRlKCIiIlNFTEVDVCBjb3VudCgqKSBhcyB0b3QgRlJPTSB1c2Vyc1Byb2ZpbGUiIiIpCiAgICAgICAgZGF0YSA9IGMuZmV0Y2hvbmUoKQogICAgICAgICNpZiB0aGUgdGFibGUgaXMgbm90IGVtcHR5IAogICAgICAgIGlmIGRhdGE+MDoKCQkJZnVsbE5hbWUgPSBwcm9maWxlRGF0YWJhc2UoKVswXQoJCQl1c2VyUG9zaXRpb24gPSBwcm9maWxlRGF0YWJhc2UoKVsxXQoJCQl1c2VyRGVzY3JpcHRpb24gPSBwcm9maWxlRGF0YWJhc2UoKVsyXQoJCQlpbWFnZSA9IHByb2ZpbGVEYXRhYmFzZSgpWzNdCgkJCXVzZXJMb2NhdGlvbiA9IHByb2ZpbGVEYXRhYmFzZSgpWzRdCiAgICAgICAgZWxzZToKCQkJZnVsbE5hbWU9JycKCQkJdXNlclBvc2l0aW9uID0gJycKCQkJdXNlckRlc2NyaXB0aW9uPScnCgkJCWltYWdlID0gJycJCQkJCiAgICAgICAgcG9zdGRhdGEgPSB7ImZ1bGxuYW1lIjpmdWxsTmFtZSwicG9zaXRpb24iOnVzZXJQb3NpdGlvbiwiZGVzY3JpcHRpb24iOnVzZXJEZXNjcmlwdGlvbiwibG9jYXRpb24iOnVzZXJMb2NhdGlvbiwncGljdHVyZSc6aW1hZ2UsImVuY3lwdGlvbiI6JzAnLCJkZWNyeXB0aW9uS2V5IjonMCd9CiAgICAgICAgI2pzb24gZW5jb2RlIGRhdGEgCiAgICAgICAgcG9zdGpzb24gPSBqc29uLmR1bXBzKHBvc3RkYXRhKQogICAgICAgIHJldHVybiBwb3N0anNvbgogICAgI1NFTkQgTUVTU0FHRQogICAgQGNoZXJyeXB5LmV4cG9zZSAgCiAgICBkZWYgcmVxdWVzdFByb2ZpbGUoc2VsZik6CiAgICAgICAgdHJ5OgoJCQkjYWxsIG9mIHRoZSByZWNlaXZpbmcgdXNlcnMgZ2V0TGlzdCBpbmZvIGluIGEgbGlzdAogICAgICAgICAgICByZWNlaXZlckRldGFpbHMgPSB1c2VyRGV0YWlscyhjaGVycnlweS5zZXNzaW9uWydyZWNlaXZlciddKQogICAgICAgICAgICAjaG9zdHMgdXBpCiAgICAgICAgICAgIHNlbmRlciA9IGNoZXJyeXB5LnNlc3Npb25bJ3VzZXJuYW1lJ10KICAgICAgICAgICAgI3JlY2VpdmluZyB1c2VycyBpcAogICAgICAgICAgICByZWNlaXZlcklQID0gcmVjZWl2ZXJEZXRhaWxzWzFdCiAgICAgICAgICAgICNyZWNlaXZpbmcgdXNlcnMgcG9ydCAKICAgICAgICAgICAgcmVjZWl2ZXJQb3J0ID0gcmVjZWl2ZXJEZXRhaWxzWzVdCiAgICAgICAgICAgICN0ZXN0IHRoZSB1c2VycyBwaW5nIEFQSSBmaXJzdCAKICAgICAgICAgICAgI3BpbmcgPSAiaHR0cDovLyIrcmVjZWl2ZXJJUCsiOiIrIHJlY2VpdmVyUG9ydCsiL3BpbmciCiAgICAgICAgICAgICNzdGFtcChlcG9jaCB0aW1lIGZsb2F0KQogICAgICAgICAgICBlcG9jaCA9IGZsb2F0KHRpbWUudGltZSgpKQogICAgICAgICAgICAjZGF0ZSB5ZWFyIGFuZCB0aW1lIG9mIHNlbnQgbWVzc2FnZSAKICAgICAgICAgICAgbm93ID0gdGltZS5zdHJmdGltZSgiJWQtJW0tJVkgJUk6JU0gJXAiLHRpbWUubG9jYWx0aW1lKGZsb2F0KHRpbWUubWt0aW1lKHRpbWUubG9jYWx0aW1lKCkpKSkpICAKICAgICAgICAgICAgI2xpc3Qgb2YgZGF0YSB0byBzZW5kIAogICAgICAgICAgICBwb3N0ZGF0YSA9IHsicHJvZmlsZV91c2VybmFtZSI6Y2hlcnJ5cHkuc2Vzc2lvblsncmVjZWl2ZXInXSwic2VuZGVyIjpjaGVycnlweS5zZXNzaW9uWyd1c2VybmFtZSddfQogICAgICAgICAgICAjanNvbiBlbmNvZGUgZGF0YSAKICAgICAgICAgICAgcG9zdGpzb24gPSBqc29uLmR1bXBzKHBvc3RkYXRhKQogICAgICAgICAgICBkZXN0ID0gImh0dHA6Ly8iK3N0cihyZWNlaXZlcklQKSsiOiIrc3RyKHJlY2VpdmVyUG9ydCkrIi9nZXRQcm9maWxlIgogICAgICAgICAgICByZXEgPSB1cmxsaWIyLlJlcXVlc3QoZGVzdCxwb3N0anNvbiwgeydDb250ZW50LVR5cGUnOidhcHBsaWNhdGlvbi9qc29uJ30pICAgCiAgICAgICAgICAgIHJlc3BvbnNlID0gdXJsbGliMi51cmxvcGVuKHJlcSkgCiAgICAgICAgICAgIGluZm8gPSByZXNwb25zZS5yZWFkKCkKICAgICAgICAgICAgcmV0dXJuIGluZm8KICAgICAgICBleGNlcHQgdXJsbGliMi5VUkxFcnJvcjoKICAgICAgICAgICAgdW5rbm93bkluZm8gPSB7ImZ1bGxuYW1lIjoidW5rbm93biIsInBvc2l0aW9uIjoidW5rbm93biIsImRlc2NyaXB0aW9uIjoiTm9uZSIsImxvY2F0aW9uIjoidW5rbm93biIsJ3BpY3R1cmUnOidodHRwczovL3dpa2kuc2hpYmJvbGV0aC5uZXQvY29uZmx1ZW5jZS9pbWFnZXMvaWNvbnMvcHJvZmlsZXBpY3MvZGVmYXVsdC5wbmcnLCJlbmN5cHRpb24iOicwJywiZGVjcnlwdGlvbktleSI6JzAnfQogICAgICAgICAgICAjanNvbiBlbmNvZGUgZGF0YSAKICAgICAgICAgICAgdW5rbm93bkpzb24gPSBqc29uLmR1bXBzKHVua25vd25JbmZvKQogICAgICAgICAgICByZXR1cm4gdW5rbm93bkluZm8gCSAgICAgICAgCiAgICAjc2hvdyB1c2VycyBwcm9maWxlCiAgICBAY2hlcnJ5cHkuZXhwb3NlICAKICAgIGRlZiB1c2VyUHJvZmlsZShzZWxmKToJCiAgICAgICAgUGFnZSA9ICcuJwogICAgICAgICNjb25uZWN0IHRvIHByb2ZpbGVkYXRhYmFzZQogICAgICAgIGNvbm4gPSBzcWxpdGUzLmNvbm5lY3QoJ2RhdGFiYXNlL3Byb2ZpbGVEYXRhYmFzZS5kYicpCiAgICAgICAgI2NyZWF0ZSBjdXJzb3Igb2JqZWN0CiAgICAgICAgYyA9IGNvbm4uY3Vyc29yKCkKICAgICAgICBjLmV4ZWN1dGUoJycnQ1JFQVRFIFRBQkxFIElGIE5PVCBFWElTVFMgdXNlcnNQcm9maWxlCiAgICAgICAgICAgICAoc2VudCB0ZXh0LHNlbmRlciB0ZXh0LG1lc3NhZ2UgdGV4dCx0aW1lIHRleHQpJycnKQogICAgICAgICNjaGVjayB0aGF0IHRoZSB0YWJsZSBpcyBub3QgZW1wdHkgCiAgICAgICAgYy5leGVjdXRlKCIiIlNFTEVDVCBjb3VudCgqKSBhcyB0b3QgRlJPTSB1c2Vyc1Byb2ZpbGUiIiIpCiAgICAgICAgZGF0YSA9IGMuZmV0Y2hvbmUoKQogICAgICAgICNpZiB0aGUgdGFibGUgaXMgbm90IGVtcHR5IAogICAgICAgIGlmIGRhdGE+MDoKCQkJZnVsbE5hbWUgPSBwcm9maWxlRGF0YWJhc2UoKVswXQoJCQl1c2VyUG9zaXRpb24gPSBwcm9maWxlRGF0YWJhc2UoKVsxXQoJCQl1c2VyRGVzY3JpcHRpb24gPSBwcm9maWxlRGF0YWJhc2UoKVsyXQoJCQlpbWFnZSA9IHByb2ZpbGVEYXRhYmFzZSgpWzNdCgkJCXVzZXJMb2NhdGlvbiA9IHByb2ZpbGVEYXRhYmFzZSgpWzRdCiAgICAgICAgZWxzZToKCQkJZnVsbE5hbWU9JycKCQkJdXNlclBvc2l0aW9uID0gJycKCQkJdXNlckRlc2NyaXB0aW9uPScnCgkJCWltYWdlID0gJycKICAgICAgICBQYWdlICs9IG9wZW4oImh0bWwvcHJvZmlsZVBhZ2UuaHRtIiwiciIpLnJlYWQoKS5mb3JtYXQobmFtZT1mdWxsTmFtZSxpbWFnZVVSTD1pbWFnZSxwb3NpdGlvbj11c2VyUG9zaXRpb24sZGVzY3JpcHRpb249dXNlckRlc2NyaXB0aW9uLGxvY2F0aW9uPXVzZXJMb2NhdGlvbikKICAgICAgICByZXR1cm4gUGFnZQogICAgICAgIAogICAgI1VwZGF0ZSBQcm9maWxlCiAgICBAY2hlcnJ5cHkuZXhwb3NlICAKICAgIGRlZiB1cGRhdGVQcm9maWxlKHNlbGYsbmFtZSxwb3NpdGlvbixkZXNjcmlwdGlvbixsb2NhdGlvbixpbWFnZSk6CQogICAgICAgIHByb2ZpbGVEYXRhYmFzZShuYW1lLHBvc2l0aW9uLGRlc2NyaXB0aW9uLGxvY2F0aW9uLGltYWdlKQogICAgICAgIHJhaXNlIGNoZXJyeXB5LkhUVFBSZWRpcmVjdCgiL3VzZXJQcm9maWxlIikKICAKICAgICAgICAKICAgIEBjaGVycnlweS5leHBvc2UKICAgIGRlZiBwaW5nKHNlbGYsc2VuZGVyPU5vbmUpOgogICAgICAgIHJldHVybiAnMCcgICAgCiAgICAgICAgCiAgICAjTElTVCBPTkxJTkUgVVNFUlMKICAgIEBjaGVycnlweS5leHBvc2UgIAogICAgI2FyZ3VtZW50IGRlc3RpbmF0aW9uIGlzIHRoZSBwb3J0IG51bWJlciAKICAgIGRlZiBsaXN0T25saW5lVXNlcnMoc2VsZiwgdXNlcm5hbWUsIHBhc3N3b3JkLCBlbmMsIGpzb24pOgogICAgICAgIGRhdGEgPSB1c2VyRGF0YWJhc2UodXNlcm5hbWUsY2hlcnJ5cHkuc2Vzc2lvblsncGFzc3dvcmQnXSkKICAgICAgICByZXR1cm4gZGF0YQogICAgICAgICAgCmRlZiBydW5NYWluQXBwKCk6CiAgICAjIENyZWF0ZSBhbiBpbnN0YW5jZSBvZiBNYWluQXBwIGFuZCB0ZWxsIENoZXJyeXB5IHRvIHNlbmQgYWxsIHJlcXVlc3RzIHVuZGVyIC8gdG8gaXQuIChpZSBhbGwgb2YgdGhlbSkKICAgIGNoZXJyeXB5LnRyZWUubW91bnQoTWFpbkFwcCgpLCAiLyIpCgogICAgIyBUZWxsIENoZXJyeXB5IHRvIGxpc3RlbiBmb3IgY29ubmVjdGlvbnMgb24gdGhlIGNvbmZpZ3VyZWQgYWRkcmVzcyBhbmQgcG9ydC4KICAgIGNoZXJyeXB5LmNvbmZpZy51cGRhdGUoeydzZXJ2ZXIuc29ja2V0X2hvc3QnOiBsaXN0ZW5faXAsCgkJCQkJCQknZW5naW5lLmF1dG9yZWxvYWQub24nOiBUcnVlLAogICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3NlcnZlci5zb2NrZXRfcG9ydCc6IGxpc3Rlbl9wb3J0LAogICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2VuZ2luZS5hdXRvcmVsb2FkLm9uJzogVHJ1ZSwKICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkKCiAgICBwcmludCAiPT09PT09PT09PT09PT09PT09PT09PT09PSIKICAgIHByaW50ICJVbml2ZXJzaXR5IG9mIEF1Y2tsYW5kIgogICAgcHJpbnQgIkNPTVBTWVMzMDIgLSBTb2Z0d2FyZSBEZXNpZ24gQXBwbGljYXRpb24iCiAgICBwcmludCAiPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSIgICAgICAgICAgICAgICAgICAgICAgIAogICAgCiAgICAjIFN0YXJ0IHRoZSB3ZWIgc2VydmVyCiAgICBjaGVycnlweS5lbmdpbmUuc3RhcnQoKQoKICAgICMgQW5kIHN0b3AgZG9pbmcgYW55dGhpbmcgZWxzZS4gTGV0IHRoZSB3ZWIgc2VydmVyIHRha2Ugb3Zlci4KICAgIGNoZXJyeXB5LmVuZ2luZS5ibG9jaygpCiAKI1J1biB0aGUgZnVuY3Rpb24gdG8gc3RhcnQgZXZlcnl0aGluZwpydW5NYWluQXBwKCkK#!/usr/bin/python
import cherrypy
import urllib
import urllib2
import codecs
import sys
import json
import os.path
import time
import base64
import sqlite3
from hash import* 
from userDatabase import*
from messageDatabase import*
import socket
from userDetails import*
from profileDatabase import*

# The address we listen for connections on
listen_ip = "0.0.0.0"
try:# if port argument is defined then set port to this 
    listen_port = int(sys.argv[1])
except (IndexError, TypeError):
	#otherwise make it 10004 by default 
    listen_port = 10004

class MainApp(object):
    #CherryPy Configuration
    _cp_config = {'tools.encode.on': True, 
                  'tools.encode.encoding': 'utf-8',
                  'tools.sessions.on' : 'True',
                 }                 
    
    # If they try somewhere we don't know, catch it here and send them to the right place.
    @cherrypy.expose
    def default(self, *args, **kwargs):
        """The default page, given when we don't recognise where the request is for."""
        Page = "I don't know where you're trying to go, so have a 404 Error."
        cherrypy.response.status = 404
        return Page
        

    #INDEX
    @cherrypy.expose
    def index(self):#index is the default page 		
        try:
        #open the message that has been sent to this port
            Page = '.'
            var = ''
            #create database called example
            conn = sqlite3.connect('database/messageDatabase.db')
            #create cursor object
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS messages
                 (sent text,sender text,message text,time text)''')
            #check that the database is not empty 
            c.execute("""SELECT count(*) as tot FROM messages""")
            data = c.fetchone()
            #display the messages onto the page '''
            if data>0:
                for mes in messageDatabase(None,cherrypy.session['receiver'],None,None):
                    text = ''.join(mes[2])
                    time = ''.join(mes[3])
                    if len(mes[2])<55:
                        colLength = str(len(mes[2]))
                        rowLength = '1'
                    else:
                        rowLength = str((len(mes[2])/55)+1)
                        colLength = '55'
                    if mes[0] == '0':
                        var+=open("html/messageFormattingReceived.htm").read().format(timeReceived=time,message=text,colLengthR=colLength,rowLengthR=rowLength)+"</br>"
                    elif mes[0] == '1':
                        var+=open("html/messageFormattingSent.htm").read().format(timeReceived=time,message=text,colLengthR=colLength,rowLengthR=rowLength)+"</br>"
                        
            Page+=open("html/messageDisplay.htm").read().format(message=var,sent='')
                        
            fullName='Unknown'
            userPosition='Unknown'
            userDescription='None'
            image='https://wiki.shibboleth.net/confluence/images/icons/profilepics/default.png'
            locate='Unknown'
            
            
			
            if cherrypy.session['receiver']!='user':  
               try:         
                    j = self.requestProfile()
                    detailsList = json.loads(j)
                    fullName = detailsList['fullname']
                    userPosition = detailsList['position']
                    userDescription = detailsList['description']
                    image = detailsList['picture']
                    locate = detailsList['location']
               except TypeError:
                    fullName='Unknown'
                    userPosition='Unknown'
                    userDescription='None'
                    image='https://wiki.shibboleth.net/confluence/images/icons/profilepics/default.png'
                    locate='Unknown'
					

            #display html for page         
            Page += open("html/messagingPage.htm","r").read().format(user =cherrypy.session['receiver'],receiver=fullName,position=userPosition,description=userDescription,img=image,location=locate)
            
            users= userDatabase(cherrypy.session['username'],cherrypy.session['password'])
            temp=''
            #display all of the users currently online
            for user in users:
                temp+=open("html/userLinks.htm").read().format(upi=''.join(user))
            #Page+=str(temp)
            Page+=open("html/userDisplay.htm").read().format(list=str(temp))  
             
        except KeyError:
     	#if theres no username we cant login so show login option until there is a username input
            Page = "."  
            f=open("html/loginPage.htm", "r")
            Page += f.read()
            f.close()
        return Page#return all the html 
        
        
    @cherrypy.expose
    def clearMessages(self):
        #create database called example
        conn = sqlite3.connect('database/messageDatabase.db')
        #create cursor object
        c = conn.cursor()
        c.execute('delete from messages')
        conn.commit()
        raise cherrypy.HTTPRedirect('/')
        

    #SIGN IN 
    @cherrypy.expose
    def signin(self, username=None, password=None):
        """Check their name and password and send them either to the main page, or back to the main login screen."""
        hashedPassword=hashText(password)
        error = self.authoriseUserLogin(username,hashedPassword)#calling the autherize username api 
        if (error == 0):
            cherrypy.session['username'] = username
            cherrypy.session['password'] = hashedPassword
            cherrypy.session['receiver'] = 'user'
            raise cherrypy.HTTPRedirect('/')
        else:
            raise cherrypy.HTTPRedirect('/')
            

    #SIGN OUT
    @cherrypy.expose
    def signout(self):
        """Logs the current user out, expires their session"""
        username = cherrypy.session.get('username')
        password = cherrypy.session['password']
        #if no ones sign in yet then do nothing
        dest = "http://cs302.pythonanywhere.com/logoff"#calling the login api to record the hardcoded values 
        postdata = {"username": username, "password": password,"enc":0}
        fptr = urllib2.urlopen(dest,urllib.urlencode(postdata))
        data = fptr.read()
        if (data == "0, Logged off successfully"):
            cherrypy.lib.sessions.expire()
            raise cherrypy.HTTPRedirect('/')#redirect to the desired page
        else:
            raise cherrypy.HTTPRedirect('/')#redirect to the desired page 
        
 
    #CSS TYPE   
    @cherrypy.expose
    def css(self,fname):
        f=open('css/'+fname,"r")
        data=f.read()
        f.close()
        return data
        

    #IMG TYPE 
    @cherrypy.expose
    def img(self, fname):
        f=open('images/'+fname, "rb")
        data = f.read()
        f.close()
        return data
        
        
    #AUTHORISE USER LOGIN 
    #not publically exposed
    def authoriseUserLogin(self, username, password):
        dest = "http://cs302.pythonanywhere.com/report"#calling the login api to record the hardcoded values 
        location = 2
        if location ==1:
            ip = (socket.gethostbyname(socket.gethostname()))
        elif location ==2:
			ip = urllib2.urlopen('http://ip.42.pl/raw').read()
        port = str(listen_port)
        postdata = {"username": username, "password": password,"location":2,"ip":ip,"port":port,"enc":0}
        fptr = urllib2.urlopen(dest,urllib.urlencode(postdata))
        data = fptr.read()
        if (data == "0, User and IP logged"):
            return 0
        else:
            return 1
            
            
    #RECEIVE MESSAGE
    @cherrypy.expose
    @cherrypy.tools.json_in() 
    def receiveMessage(self):
        jsonDict = cherrypy.request.json
        epoch = jsonDict['stamp']
        now = time.strftime("%d-%m-%Y %I:%M %p",time.localtime(epoch))
        messageDatabase('0',jsonDict['sender'],jsonDict['message'],now) 
        return '0'
        
        
    #SEND MESSAGE
    @cherrypy.expose  
    def sendMessage(self,message,markDown = 0,encryption = 0, hashing = 0, decryptionKey= 0,hash1 = 0):
        try:
			#all of the receiving users getList info in a list
            receiverDetails = userDetails(cherrypy.session['receiver'])
            #receiving users upi
            destination = receiverDetails[0]
            #hosts upi
            sender = cherrypy.session['username']
            #receiving users ip
            receiverIP = receiverDetails[1]
            #receiving users port 
            receiverPort = receiverDetails[5]
            #test the users ping API first 
            #ping = "http://"+receiverIP+":"+ receiverPort+"/ping"
            #stamp(epoch time float)
            epoch = float(time.time())
            #date year and time of sent message 
            now = time.strftime("%d-%m-%Y %I:%M %p",time.localtime(float(time.mktime(time.localtime()))))  
            #list of data to send 
            postdata = {"sender":sender,"destination":destination,"message": message,"stamp":epoch,"encryption":encryption,"hashing":hashing,"hash":hash1,"decryptionKey":decryptionKey}
            #json encode data 
            postjson = json.dumps(postdata)
            dest = "http://"+str(receiverIP)+":"+str(receiverPort)+"/receiveMessage"
            #dest = "http://127.0.0.1:2345/receiveMessage"
            req = urllib2.Request(dest,postjson, {'Content-Type':'application/json'})   
            messageDatabase('1',destination,message,now)
            response = urllib2.urlopen(req) 
            raise cherrypy.HTTPRedirect("/")
        except urllib2.URLError:
			return "User cannot currently receive messages "
			
			
	    #RECEIVE MESSAGE
    @cherrypy.expose
    @cherrypy.tools.json_in() 
    def receiveFile(self):
        jsonDict = cherrypy.request.json
        epoch = jsonDict['stamp']
        writeFile = base64.b64decode(jsonDict['file'])
        now = time.strftime("%d-%m-%Y %I:%M %p",time.localtime(epoch))
        mfile = open("files/"+jsonDict['filename'], "a")
        mfile.write(writeFile)
        mfile.close()
        messageDatabase('4',jsonDict['sender'],jsonDict['filename'],now) 
        return '0'
        
        	
    @cherrypy.expose		
    def sendFile(self,filename,mimeType):
	    #all of the receiving users getList info in a list
        receiverDetails = userDetails(cherrypy.session['receiver'])
        #hosts upi
        sender = cherrypy.session['username']
        #receiving users ip
        receiverIP = receiverDetails[1]
        #receiving users port 
        receiverPort = receiverDetails[5]
        encryption = '0'
        hash1='0'
        hashing='0'
        decryptionKey='0'
        sender = cherrypy.session['username']
        destination = cherrypy.session['receiver']
		#stamp(epoch time float)
        epoch = float(time.time())
        now = time.strftime("%d-%m-%Y %I:%M %p",time.localtime(epoch))
        with open("mainServer.py", "rb") as image_file:
            fileB64 = base64.b64encode(image_file.read())
        contentType = 'text'
        postdata = {"sender":sender,"destination":destination,"file": fileB64,"filename":filename,"content_type":mimeType,"stamp":epoch,"encryption":encryption,"hashing":hashing,"hash":hash1,"decryptionKey":decryptionKey}
        #json encode data 
        postjson = json.dumps(postdata)
        #dest = "http://"+str(receiverIP)+":"+str(receiverPort)+"/receiveFile"
        dest = "http://127.0.0.1:2345/receiveFile"
        req = urllib2.Request(dest,postjson, {'Content-Type':'application/json'})   
        messageDatabase('3',destination,filename,now)
        response = urllib2.urlopen(req) 
        raise cherrypy.HTTPRedirect("/")
        
        
        
	#set receiver	
    @cherrypy.expose
    def setReceiver(self,receiver):
        cherrypy.session['receiver'] = receiver
        raise cherrypy.HTTPRedirect("/")

        
   #Get Profile
    @cherrypy.expose  
    @cherrypy.tools.json_in() 
    def getProfile(self):
        jsonDict = cherrypy.request.json
		#connect to profiledatabase
        conn = sqlite3.connect('database/profileDatabase.db')
        #create cursor object
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS usersProfile
              (sent text,sender text,message text,time text)''')
        #check that the table is not empty 
        c.execute("""SELECT count(*) as tot FROM usersProfile""")
        data = c.fetchone()
        #if the table is not empty 
        if data>0:
			fullName = profileDatabase()[0]
			userPosition = profileDatabase()[1]
			userDescription = profileDatabase()[2]
			image = profileDatabase()[3]
			userLocation = profileDatabase()[4]
        else:
			fullName=''
			userPosition = ''
			userDescription=''
			image = ''				
        postdata = {"fullname":fullName,"position":userPosition,"description":userDescription,"location":userLocation,'picture':image,"encyption":'0',"decryptionKey":'0'}
        #json encode data 
        postjson = json.dumps(postdata)
        return postjson
    #SEND MESSAGE
    @cherrypy.expose  
    def requestProfile(self):
        try:
			#all of the receiving users getList info in a list
            receiverDetails = userDetails(cherrypy.session['receiver'])
            #hosts upi
            sender = cherrypy.session['username']
            #receiving users ip
            receiverIP = receiverDetails[1]
            #receiving users port 
            receiverPort = receiverDetails[5]
            #test the users ping API first 
            #ping = "http://"+receiverIP+":"+ receiverPort+"/ping"
            #stamp(epoch time float)
            epoch = float(time.time())
            #date year and time of sent message 
            now = time.strftime("%d-%m-%Y %I:%M %p",time.localtime(float(time.mktime(time.localtime()))))  
            #list of data to send 
            postdata = {"profile_username":cherrypy.session['receiver'],"sender":cherrypy.session['username']}
            #json encode data 
            postjson = json.dumps(postdata)
            dest = "http://"+str(receiverIP)+":"+str(receiverPort)+"/getProfile"
            req = urllib2.Request(dest,postjson, {'Content-Type':'application/json'})   
            response = urllib2.urlopen(req) 
            info = response.read()
            return info
        except urllib2.URLError:
            unknownInfo = {"fullname":"unknown","position":"unknown","description":"None","location":"unknown",'picture':'https://wiki.shibboleth.net/confluence/images/icons/profilepics/default.png',"encyption":'0',"decryptionKey":'0'}
            #json encode data 
            unknownJson = json.dumps(unknownInfo)
            return unknownInfo 	        
    #show users profile
    @cherrypy.expose  
    def userProfile(self):	
        Page = '.'
        #connect to profiledatabase
        conn = sqlite3.connect('database/profileDatabase.db')
        #create cursor object
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS usersProfile
             (sent text,sender text,message text,time text)''')
        #check that the table is not empty 
        c.execute("""SELECT count(*) as tot FROM usersProfile""")
        data = c.fetchone()
        #if the table is not empty 
        if data>0:
			fullName = profileDatabase()[0]
			userPosition = profileDatabase()[1]
			userDescription = profileDatabase()[2]
			image = profileDatabase()[3]
			userLocation = profileDatabase()[4]
        else:
			fullName=''
			userPosition = ''
			userDescription=''
			image = ''
        Page += open("html/profilePage.htm","r").read().format(name=fullName,imageURL=image,position=userPosition,description=userDescription,location=userLocation)
        return Page
        
    #Update Profile
    @cherrypy.expose  
    def updateProfile(self,name,position,description,location,image):	
        profileDatabase(name,position,description,location,image)
        raise cherrypy.HTTPRedirect("/userProfile")
  
        
    @cherrypy.expose
    def ping(self,sender=None):
        return '0'    
        
    #LIST ONLINE USERS
    @cherrypy.expose  
    #argument destination is the port number 
    def listOnlineUsers(self, username, password, enc, json):
        data = userDatabase(username,cherrypy.session['password'])
        return data
          
def runMainApp():
    # Create an instance of MainApp and tell Cherrypy to send all requests under / to it. (ie all of them)
    cherrypy.tree.mount(MainApp(), "/")

    # Tell Cherrypy to listen for connections on the configured address and port.
    cherrypy.config.update({'server.socket_host': listen_ip,
							'engine.autoreload.on': True,
                            'server.socket_port': listen_port,
                            'engine.autoreload.on': True,
                           })

    print "========================="
    print "University of Auckland"
    print "COMPSYS302 - Software Design Application"
    print "========================================"                       
    
    # Start the web server
    cherrypy.engine.start()

    # And stop doing anything else. Let the web server take over.
    cherrypy.engine.block()
 
#Run the function to start everything
runMainApp()
