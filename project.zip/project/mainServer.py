#!/usr/bin/python
import cherrypy
import urllib
import urllib2
import codecs
import sys
import json
import os.path
import time
import base64
import sqlite3
from hash import* 
from userDatabase import*
from messageDatabase import*
import socket
from userDetails import*
from profileDatabase import*
import binascii
from mimetypes import MimeTypes

# The address we listen for connections on
listen_ip = "0.0.0.0"
try:# if port argument is defined then set port to this 
    listen_port = int(sys.argv[1])
except (IndexError, TypeError):
	#otherwise make it 10004 by default 
    listen_port = 10004

class MainApp(object):
    #CherryPy Configuration
    _cp_config = {'tools.encode.on': True, 
                  'tools.encode.encoding': 'utf-8',
                  'tools.sessions.on' : 'True',
                 }                 
    
    # If they try somewhere we don't know, catch it here and send them to the right place.
    @cherrypy.expose
    def default(self, *args, **kwargs):
        """The default page, given when we don't recognise where the request is for."""
        Page = "I don't know where you're trying to go, so have a 404 Error."
        cherrypy.response.status = 404
        return Page
        

    #INDEX
    @cherrypy.expose
    def index(self):#index is the default page 		
        try:
        #open the message that has been sent to this port
            Page = '.'
            var = ''
            #create database called example
            conn = sqlite3.connect('database/messageDatabase.db')
            #create cursor object
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS messages
                 (sent text,sender text,message text,time text)''')
            #check that the database is not empty 
            c.execute("""SELECT count(*) as tot FROM messages""")
            data = c.fetchone()
            #display the messages onto the page '''
            if data>0:
                for mes in messageDatabase(None,cherrypy.session['receiver'],None,None):
                    text = ''.join(mes[2])
                    time = ''.join(mes[3])
                    dir_path = os.path.dirname(os.path.realpath(__file__))
                    address = 'file:///'+dir_path+'/files/'+text
                    if len(mes[2])<55:
                        colLength = str(len(mes[2]))
                        rowLength = '1'
                    else:
                        rowLength = str((len(mes[2])/55)+1)
                        colLength = '55'
                    if mes[0] == '0':
                        var+=open("html/messageFormattingReceived.htm").read().format(timeReceived=time,message=text,colLengthR=colLength,rowLengthR=rowLength)+"</br>"
                    elif mes[0] == '1':
                        var+=open("html/messageFormattingSent.htm").read().format(timeReceived=time,message=text,colLengthR=colLength,rowLengthR=rowLength)+"</br>"
                    elif mes[0] == '2':
                        var+=open("html/messageFormattingReceivedFile.htm").read().format(timeReceived=time,message=text,colLengthR=colLength,rowLengthR=rowLength,link=address)+"</br>"
                    elif mes[0] == '3':
                        var+=open("html/messageFormattingSentFile.htm").read().format(timeReceived=time,message=text,link=address)+"</br>"	
            Page+=open("html/messageDisplay.htm").read().format(message=var,sent='')
                        
            fullName='Unknown'
            userPosition='Unknown'
            userDescription='None'
            image='https://wiki.shibboleth.net/confluence/images/icons/profilepics/default.png'
            locate='Unknown'
            
            
			
            if cherrypy.session['receiver']!='user':  
               try:         
                    j = self.requestProfile()
                    detailsList = json.loads(j)
                    fullName = detailsList['fullname']
                    userPosition = detailsList['position']
                    userDescription = detailsList['description']
                    image = detailsList['picture']
                    locate = detailsList['location']
               except TypeError:
                    fullName='Unknown'
                    userPosition='Unknown'
                    userDescription='None'
                    image='https://wiki.shibboleth.net/confluence/images/icons/profilepics/default.png'
                    locate='Unknown'
					

            #display html for page         
            Page += open("html/messagingPage.htm","r").read().format(user =cherrypy.session['receiver'],receiver=fullName,position=userPosition,description=userDescription,img=image,location=locate)
            
            users= userDatabase(cherrypy.session['username'],cherrypy.session['password'])
            temp=''
            #display all of the users currently online
            for user in users:
                temp+=open("html/userLinks.htm").read().format(upi=''.join(user))
            #Page+=str(temp)
            Page+=open("html/userDisplay.htm").read().format(list=str(temp))  
             
        except KeyError:
     	#if theres no username we cant login so show login option until there is a username input
            Page = "."  
            f=open("html/loginPage.htm", "r")
            Page += f.read()
            f.close()
        return Page#return all the html 
        
        
    @cherrypy.expose
    def clearMessages(self):
        #create database called example
        conn = sqlite3.connect('database/messageDatabase.db')
        #create cursor object
        c = conn.cursor()
        c.execute('delete from messages')
        conn.commit()
        raise cherrypy.HTTPRedirect('/')
        

    #SIGN IN 
    @cherrypy.expose
    def signin(self, username=None, password=None):
        """Check their name and password and send them either to the main page, or back to the main login screen."""
        hashedPassword=hashText(password)
        error = self.authoriseUserLogin(username,hashedPassword)#calling the autherize username api 
        if (error == 0):
            cherrypy.session['username'] = username
            cherrypy.session['password'] = hashedPassword
            cherrypy.session['receiver'] = 'user'
            raise cherrypy.HTTPRedirect('/')
        else:
            raise cherrypy.HTTPRedirect('/')
            

    #SIGN OUT
    @cherrypy.expose
    def signout(self):
        """Logs the current user out, expires their session"""
        username = cherrypy.session.get('username')
        password = cherrypy.session['password']
        #if no ones sign in yet then do nothing
        dest = "http://cs302.pythonanywhere.com/logoff"#calling the login api to record the hardcoded values 
        postdata = {"username": username, "password": password,"enc":0}
        fptr = urllib2.urlopen(dest,urllib.urlencode(postdata))
        data = fptr.read()
        if (data == "0, Logged off successfully"):
            cherrypy.lib.sessions.expire()
            raise cherrypy.HTTPRedirect('/')#redirect to the desired page
        else:
            raise cherrypy.HTTPRedirect('/')#redirect to the desired page 
        
 
    #CSS TYPE   
    @cherrypy.expose
    def css(self,fname):
        f=open('css/'+fname,"r")
        data=f.read()
        f.close()
        return data
        

    #IMG TYPE 
    @cherrypy.expose
    def img(self, fname):
        f=open('images/'+fname, "rb")
        data = f.read()
        f.close()
        return data
        
        
    #AUTHORISE USER LOGIN 
    #not publically exposed
    def authoriseUserLogin(self, username, password):
        dest = "http://cs302.pythonanywhere.com/report"#calling the login api to record the hardcoded values 
        location = 1
        if location ==1:
            ip = (socket.gethostbyname(socket.gethostname()))
        elif location ==2:
			ip = urllib2.urlopen('http://ip.42.pl/raw').read()
        port = str(listen_port)
        postdata = {"username": username, "password": password,"location":1,"ip":ip,"port":port,"enc":0}
        fptr = urllib2.urlopen(dest,urllib.urlencode(postdata))
        data = fptr.read()
        if (data == "0, User and IP logged"):
            return 0
        else:
            return 1
            
            
    #RECEIVE MESSAGE
    @cherrypy.expose
    @cherrypy.tools.json_in() 
    def receiveMessage(self):
        jsonDict = cherrypy.request.json
        epoch = jsonDict['stamp']
        now = time.strftime("%d-%m-%Y %I:%M %p",time.localtime(epoch))
        messageDatabase('0',jsonDict['sender'],jsonDict['message'],now) 
        return '0'
        
        
    #SEND MESSAGE
    @cherrypy.expose  
    def sendMessage(self,message,markDown = 0,encryption = 0, hashing = 0, decryptionKey= 0,hash1 = 0):
        try:
			#all of the receiving users getList info in a list
            receiverDetails = userDetails(cherrypy.session['receiver'])
            #receiving users upi
            destination = receiverDetails[0]
            #hosts upi
            sender = cherrypy.session['username']
            #receiving users ip
            receiverIP = receiverDetails[1]
            #receiving users port 
            receiverPort = receiverDetails[5]
            #test the users ping API first 
            #ping = "http://"+receiverIP+":"+ receiverPort+"/ping"
            #stamp(epoch time float)
            epoch = float(time.time())
            #date year and time of sent message 
            now = time.strftime("%d-%m-%Y %I:%M %p",time.localtime(float(time.mktime(time.localtime()))))  
            #list of data to send 
            postdata = {"sender":sender,"destination":destination,"message": message,"stamp":epoch,"encryption":encryption,"hashing":hashing,"hash":hash1,"decryptionKey":decryptionKey}
            #json encode data 
            postjson = json.dumps(postdata)
            dest = "http://"+str(receiverIP)+":"+str(receiverPort)+"/receiveMessage"
            #dest = "http://127.0.0.1:2345/receiveMessage"
            req = urllib2.Request(dest,postjson, {'Content-Type':'application/json'})   
            messageDatabase('1',destination,message,now)
            response = urllib2.urlopen(req) 
            raise cherrypy.HTTPRedirect("/")
        except urllib2.URLError:
			return "User cannot currently receive messages "
			
			
	    #RECEIVE MESSAGE
    @cherrypy.expose
    @cherrypy.tools.json_in() 
    def receiveFile(self):
        jsonDict = cherrypy.request.json
        epoch = jsonDict['stamp']
        writeFile = base64.b64decode(jsonDict['file'])
        now = time.strftime("%d-%m-%Y %I:%M %p",time.localtime(epoch))
        mfile = open("files/"+jsonDict['filename'], "a")
        mfile.write(writeFile)
        mfile.close()
        messageDatabase('2',jsonDict['sender'],jsonDict['filename'],now) 
        return '0'
        
        	
    @cherrypy.expose		
    def sendFile(self,filename,mimeType):
        #all of the receiving users getList info in a list
        receiverDetails = userDetails(cherrypy.session['receiver'])
        #hosts upi
        sender = cherrypy.session['username']
        #receiving users ip
        receiverIP = receiverDetails[1]
        #receiving users port 
        receiverPort = receiverDetails[5]
        encryption = '0'
        hash1='0'
        hashing='0'
        decryptionKey='0'
        sender = cherrypy.session['username']
        destination = cherrypy.session['receiver']
		#stamp(epoch time float)
        epoch = float(time.time())
        now = time.strftime("%d-%m-%Y %I:%M %p",time.localtime(epoch))
        with open('files/a', "rb") as image_file:
            fileB64 = base64.b64encode(image_file.read())
        mimeType = 'text'
        postdata = {"sender":sender,"destination":destination,"file": fileB64,"filename":'maiServer.py',"content_type":mimeType,"stamp":epoch,"encryption":encryption,"hashing":hashing,"hash":hash1,"decryptionKey":decryptionKey}
        #json encode data 
        postjson = json.dumps(postdata)
        #dest = "http://"+str(receiverIP)+":"+str(receiverPort)+"/receiveFile"
        dest = "http://127.0.0.1:2345/receiveFile"
        req = urllib2.Request(dest,postjson, {'Content-Type':'application/json'})   
        messageDatabase('3',destination,'mainServer.py',now)
        response = urllib2.urlopen(req)
        page = filename.file.read()
        return page 
        #raise cherrypy.HTTPRedirect("/")
        
        
        
	#set receiver	
    @cherrypy.expose
    def setReceiver(self,receiver):
        cherrypy.session['receiver'] = receiver
        raise cherrypy.HTTPRedirect("/")

        
   #Get Profile
    @cherrypy.expose  
    @cherrypy.tools.json_in() 
    def getProfile(self):
        jsonDict = cherrypy.request.json
		#connect to profiledatabase
        conn = sqlite3.connect('database/profileDatabase.db')
        #create cursor object
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS usersProfile
              (sent text,sender text,message text,time text)''')
        #check that the table is not empty 
        c.execute("""SELECT count(*) as tot FROM usersProfile""")
        data = c.fetchone()
        #if the table is not empty 
        if data>0:
			fullName = profileDatabase()[0]
			userPosition = profileDatabase()[1]
			userDescription = profileDatabase()[2]
			image = profileDatabase()[3]
			userLocation = profileDatabase()[4]
        else:
			fullName=''
			userPosition = ''
			userDescription=''
			image = ''				
        postdata = {"fullname":fullName,"position":userPosition,"description":userDescription,"location":userLocation,'picture':image,"encyption":'0',"decryptionKey":'0'}
        #json encode data 
        postjson = json.dumps(postdata)
        return postjson
    #SEND MESSAGE
    @cherrypy.expose  
    def requestProfile(self):
        try:
			#all of the receiving users getList info in a list
            receiverDetails = userDetails(cherrypy.session['receiver'])
            #hosts upi
            sender = cherrypy.session['username']
            #receiving users ip
            receiverIP = receiverDetails[1]
            #receiving users port 
            receiverPort = receiverDetails[5]
            #test the users ping API first 
            #ping = "http://"+receiverIP+":"+ receiverPort+"/ping"
            #stamp(epoch time float)
            epoch = float(time.time())
            #date year and time of sent message 
            now = time.strftime("%d-%m-%Y %I:%M %p",time.localtime(float(time.mktime(time.localtime()))))  
            #list of data to send 
            postdata = {"profile_username":cherrypy.session['receiver'],"sender":cherrypy.session['username']}
            #json encode data 
            postjson = json.dumps(postdata)
            dest = "http://"+str(receiverIP)+":"+str(receiverPort)+"/getProfile"
            req = urllib2.Request(dest,postjson, {'Content-Type':'application/json'})   
            response = urllib2.urlopen(req) 
            info = response.read()
            return info
        except urllib2.URLError:
            unknownInfo = {"fullname":"unknown","position":"unknown","description":"None","location":"unknown",'picture':'https://wiki.shibboleth.net/confluence/images/icons/profilepics/default.png',"encyption":'0',"decryptionKey":'0'}
            #json encode data 
            unknownJson = json.dumps(unknownInfo)
            return unknownInfo 	        
    #show users profile
    @cherrypy.expose  
    def userProfile(self):	
        Page = '.'
        #connect to profiledatabase
        conn = sqlite3.connect('database/profileDatabase.db')
        #create cursor object
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS usersProfile
             (sent text,sender text,message text,time text)''')
        #check that the table is not empty 
        c.execute("""SELECT count(*) as tot FROM usersProfile""")
        data = c.fetchone()
        #if the table is not empty 
        if data>0:
			fullName = profileDatabase()[0]
			userPosition = profileDatabase()[1]
			userDescription = profileDatabase()[2]
			image = profileDatabase()[3]
			userLocation = profileDatabase()[4]
        else:
			fullName=''
			userPosition = ''
			userDescription=''
			image = ''
        Page += open("html/profilePage.htm","r").read().format(name=fullName,imageURL=image,position=userPosition,description=userDescription,location=userLocation)
        return Page
        
    #Update Profile
    @cherrypy.expose  
    def updateProfile(self,name,position,description,location,image):	
        profileDatabase(name,position,description,location,image)
        raise cherrypy.HTTPRedirect("/userProfile")
  
        
    @cherrypy.expose
    def ping(self,sender=None):
        return '0'    
        
    #LIST ONLINE USERS
    @cherrypy.expose  
    #argument destination is the port number 
    def listOnlineUsers(self, username, password, enc, json):
        data = userDatabase(username,cherrypy.session['password'])
        return data
          
def runMainApp():
    # Create an instance of MainApp and tell Cherrypy to send all requests under / to it. (ie all of them)
    cherrypy.tree.mount(MainApp(), "/")

    # Tell Cherrypy to listen for connections on the configured address and port.
    cherrypy.config.update({'server.socket_host': listen_ip,
							'engine.autoreload.on': True,
                            'server.socket_port': listen_port,
                            'engine.autoreload.on': True,
                           })

    print "========================="
    print "University of Auckland"
    print "COMPSYS302 - Software Design Application"
    print "========================================"                       
    
    # Start the web server
    cherrypy.engine.start()

    # And stop doing anything else. Let the web server take over.
    cherrypy.engine.block()
 
#Run the function to start everything
runMainApp()
