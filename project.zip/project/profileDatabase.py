import sqlite3
import json
import urllib
import urllib2
import os.path
def profileDatabase(name='',position='',description='',location='',image=''):
    #connect to database
    conn = sqlite3.connect('database/profileDatabase.db')
    #create cursor object
    c = conn.cursor()
        
    #create a table for the profile  info if it doesn't already exist 
    c.execute('''CREATE TABLE IF NOT EXISTS usersProfile
              (name text,position text,description text, location text,image text)''')
    #check that the database is not empty 
    c.execute("""SELECT count(*) as tot FROM usersProfile""")
    data = c.fetchone()
    
    #if table is not empty
    if data>0:
        #return profile details of previous entry
        c.execute('SELECT {coi} FROM {tn}'.\
        format(coi='name',tn='usersProfile'))
        tempName = c.fetchall()
        prevName=''
        for temp in tempName:
            prevName=temp
        c.execute('SELECT {coi} FROM {tn}'.\
        format(coi='position',tn='usersProfile'))
        tempPosition = c.fetchall()
        prevPosition=''
        for temp in tempPosition:
            prevPosition=temp
        c.execute('SELECT {coi} FROM {tn}'.\
        format(coi='description',tn='usersProfile'))
        tempDescription = c.fetchall()
        prevDescription=''
        for temp in tempDescription:
            prevDescription=temp
        c.execute('SELECT {coi} FROM {tn}'.\
        format(coi='location',tn='usersProfile'))
        prevLocation=''
        tempLocation = c.fetchall()
        for temp in tempLocation:
            prevLocation=temp
        c.execute('SELECT {coi} FROM {tn}'.\
        format(coi='image',tn='usersProfile'))
        prevImage=''
        tempImage = c.fetchall()
        for temp in tempImage:
            prevImage=temp
        
        #if user has not updates some details then keep them the same as previous  
        details=[]
        if name=='':
            details.append(1)
            details[0]=''.join(prevName)
        else:
			details.append(1)
			details[0]=name
        if position=='':
            details.append(1)
            details[1]=''.join(prevPosition)
        else:
			details.append(1)
			details[1]=position
        if description=='':
            details.append(1)
            details[2]=''.join(prevDescription)
        else:
			details.append(1)
			details[2]=description
        if location=='':
            details.append(1)
            details[3]=''.join(prevLocation)
        else:
			details.append(1)
			details[3]=location
        if image=='':
            details.append(1)
            details[4]=''.join(prevImage)
        else:
			details.append(1)
			details[4]=image
    #if table is empty then just write straight into the table
    else:	
        details = []
        details.append(1)
        details[0]=name
        details.append(1)
        details[1]=position
        details.append(1)
        details[2]=description
        details.append(1)
        details[3]=location
        details.append(1)
        details[4]=image
        
    c.execute('delete from usersProfile')
    c.executemany('INSERT OR IGNORE INTO usersProfile VALUES(?,?,?,?,?)',(details,)) 
    # Save (commit) the changes
    conn.commit()
    #return details
    c.execute('SELECT {coi} FROM {tn}'.\
              format(coi = 'name',tn='usersProfile'))
    fullnameTemp = c.fetchall()
    for temp in fullnameTemp:
		fullname=temp
    c.execute('SELECT {coi} FROM {tn}'.\
        format(coi = 'position',tn='usersProfile'))
    userPositionTemp = c.fetchall()
    for temp in userPositionTemp:
		userPosition = temp
    c.execute('SELECT {coi} FROM {tn}'.\
        format(coi = 'description',tn='usersProfile'))
    userDescriptionTemp = c.fetchall()
    for temp in userDescriptionTemp:
		userDescription=temp
    c.execute('SELECT {coi} FROM {tn}'.\
        format(coi = 'image',tn='usersProfile'))
    userImageTemp = c.fetchall()
    for temp in userImageTemp:
		userImage=temp
    c.execute('SELECT {coi} FROM {tn}'.\
        format(coi = 'location',tn='usersProfile'))
    userLocationTemp = c.fetchall()
    for temp in userLocationTemp:
		userLocation=temp
    conn.close()
    
    info=[]
    info.append(1)
    info[0]=''.join(fullname)
    info.append(1)
    info[1]=''.join(userPosition)
    info.append(1)
    info[2]=''.join(userDescription)
    info.append(1)
    info[3]=''.join(userImage)
    info.append(1)
    info[4]=''.join(userLocation)
    
    return info


