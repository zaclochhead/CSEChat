import sqlite3
import json
import urllib
import urllib2
import os.path
def userDatabase(username,password):
    #create database called example
    conn = sqlite3.connect('database/usersDatabase.db')
    #create cursor object
    c = conn.cursor()
        
    #create a table for the users info if it doesn't already exist 
    c.execute('''CREATE TABLE IF NOT EXISTS usersOnline
              (username text, ip decimal,publicKey integer, location integer,lastLogin integer, port integer, UNIQUE(username))''')
              
    #read the json dict of users info from getlist
    dest = "http://cs302.pythonanywhere.com/getList"
    postdata = {"username": username, "password":password,"enc":0,"json":1}
    fptr = urllib2.urlopen(dest,urllib.urlencode(postdata))
    data = fptr.read()
    users = json.loads(data)
    userValues=users.values()
    i = 0
    userDetails = []
    while i<len(userValues):
		#if the user has a public key defined then store it straight in the data base
        if 'publicKey' in userValues[i].keys():
            userDetails.append(1)
            userDetails[i] = userValues[i].values()
            i+=1
        #if the user doesn't have a public key then give 0 value and then store in database
        else:
            userDetails.append(1)
            #convert dict to list so publicKey can be added 
            userList = userValues[i].items()
            userList.append(('publicKey',0))
            #convert back to dictionary 
            userValues[i]= dict(userList)
            userDetails[i] = userValues[i].values()
            i+=1
    fptr.close()
    #delete previous usersOnline incase people from old database are no longer online 
    c.execute('delete from usersOnline')
    #insert user details into the database 
    c.executemany('INSERT OR IGNORE INTO usersOnline VALUES(?,?,?,?,?,?)',userDetails) 
    # Save (commit) the changes
    conn.commit()
    
    table_name = 'usersOnline'
    username_column = 'username'
    ip_column = 'ip'
    port_column = 'port'
    location_column = 'location'
    
    #return only the usernames 
    c.execute('SELECT {coi1} FROM {tn}'.\
              format(coi1 = username_column, tn=table_name))
    all_rows = c.fetchall()
    
    conn.close()
    return all_rows
