import sqlite3
import json
import urllib
import urllib2
import os.path
    
def userDetails(upi):
    #create database called example
    conn = sqlite3.connect('database/usersDatabase.db')
    #create cursor object
    c = conn.cursor()   
    #create a table for the users info if it doesn't already exist 
    c.execute('''CREATE TABLE IF NOT EXISTS usersOnline
              (username text, ip decimal,publicKey integer, location integer,lastLogin integer, port integer, UNIQUE(username))''')
    c.execute("SELECT * FROM {tn} WHERE {cn}='{user}'".\
            format(tn='usersOnline', cn='username', user=upi))
    all_rows = c.fetchall()
    
    userInfo = []
    i=0
    for details in all_rows[0]:
        userInfo.append(1)
        userInfo[i]=details
        i+=1
    return userInfo
